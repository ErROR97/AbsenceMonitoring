<?php

$connection = mysqli_connect("matingrimes.ir", "matinbar_office", "Office1398", "matinbar_officialAutomation");
mysqli_set_charset($connection,"utf8");
