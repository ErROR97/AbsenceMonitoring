<?php

require "connection.php";

$query = 'SELECT * FROM sport;';
$result = mysqli_query($connection, $query) or die('error: ' .mysql_error());

$controlArray = array();
if($result -> num_rows > 0) {
    for($i = 0; $i < $result -> num_rows; $i++) {
        $controlArray[$i] = $result -> fetch_assoc();
    }
    $json = json_encode($controlArray, JSON_UNESCAPED_UNICODE);
    echo "success_$json";
} else {
  echo "error";
}
