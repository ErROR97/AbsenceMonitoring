<?php
require "connection.php";
error_reporting(E_ERROR | E_PARSE);

$id = $_POST['id'];
$date = $_POST['date'];

//$change = $_POST['change'];
//$time = $_POST['time'];

//$type = $_POST['type'];

// $id = "34";
// $date = "wed";
$change = "date";





if ($change == "type") {
    $queryUpdate = 'UPDATE sport SET type = ? WHERE id = ? ;';
    $resultUpdate = mysqli_prepare($connection, $queryUpdate) or die('error: ' .mysqli_error());
    mysqli_stmt_bind_param($resultUpdate, 'ss', $type,$id);
    if (mysqli_stmt_execute($resultUpdate)) {
        echo "success";
    } else {
        echo "error";
    }
}
elseif ($change == "date") {
    $querySerch = 'SELECT * FROM sport WHERE id = "'.$id.'" ;';
    $resultSerch = mysqli_query($connection, $querySerch) or die('error: ' .mysql_error());
    $SportInfoArr = mysqli_fetch_assoc($resultSerch);

    $JSONobjOldDate = json_decode($SportInfoArr['date']);
    //echo count(explode("-",$JSONobjOldDate->day))-1;
    if (count(explode("-",$JSONobjOldDate->day))-1 > 1) {
        $JSONobjCapacity = json_decode($SportInfoArr['capacity'],true);
        $JSONobjPersonalId = json_decode($SportInfoArr['personalid'],true);
        $JSONobjStatus = json_decode($SportInfoArr['status'],true);

        /* 
        */
        $arryNewDate = explode("-",$date);
        $dateJson = "";
        for ($i = 0; $i < count($arryNewDate); $i++){
        $dateJson->day .= $arryNewDate[$i]."-";
        }
        $JSONobjNewDate= json_encode($dateJson);
        $arryDateOld = explode("-",$JSONobjOldDate->day);
        $arryDelete = array();
        //////
        array_push($arryDelete,$date);
        /////

        /*
        for ($i = 0; $i < count($arryDateOld); $i++) { 
        $flag = "false";
        for ($j = 0; $j < count($arryNewDate); $j++) { 
            if ($arryDateOld[$i] == $arryNewDate[$j]) {
                $flag = "true";
            break;
            }
        }
        if ($flag == "false") {
            if (count($arryDelete) == 0) {
                $arryDelete[0] = $arryDateOld[$i];
            }
            else {
                for ($k = 1; $k < count($arryDelete); $k++) { 
                    $arryDelete[$k] = $arryDateOld[$i];
                }
            }
        }
        }
        */

        $warningPersonalId = array();
        for ($i=0; $i < count($arryDelete); $i++) {
            if (count(explode("-",$JSONobjPersonalId->$arryDelete[$i])) > 0 ) {
                $arryPersonid = explode("-",$JSONobjPersonalId->$arryDelete[$i]);
                for ($j=0; $j < count($arryPersonid); $j++) { 
                    array_push($warningPersonalId,$arryPersonid[$j]);
                }
            }
        }
        if (count($warningPersonalId) == 0) {
            $warninJson = "";
            for ($i=0; $i < count($warningPersonalId); $i++) { 
                $warninJson->warning .= $warningPersonalId[$i]."-";
            }
            echo "error"."_".json_encode($warninJson,true);
        }else {
            for ($i=0; $i < count($arryDelete); $i++) { 
                unset($JSONobjCapacity[$arryDelete[$i]]);
                unset($JSONobjPersonalId[$arryDelete[$i]]);
                unset($JSONobjStatus[$arryDelete[$i]]);  
            }
            $arryDateUpdate = explode("-",$JSONobjOldDate->day);
            $arrydateUpdate = array();
            for ($i=0; $i < count($arryDateUpdate); $i++) { 
                if (($arryDateUpdate[$i] != $date) AND $date != "") {
                    array_push($arrydateUpdate,$arryDateUpdate[$i]);
                }
            }
            $jsonDate = "";
            for ($i = 0; $i < count($arrydateUpdate); $i++){
                $jsonDate->day .= $arrydateUpdate[$i]."-";
            }
            $stringDate=$jsonDate->day;
            $jsonDate->day = substr($jsonDate->day,0,strlen($jsonDate->day) - 1);
            $JSONNewDate= json_encode($jsonDate);
            $queryUpdate = 'UPDATE sport SET personalid = ? , capacity = ? , status = ? , date = ? WHERE id = ? ;';
            $resultUpdate = mysqli_prepare($connection, $queryUpdate) or die('error: ' .mysqli_error());
            mysqli_stmt_bind_param($resultUpdate, 'sssss',json_encode($JSONobjPersonalId),json_encode($JSONobjCapacity),json_encode($JSONobjStatus),$JSONNewDate,$id);
        if (mysqli_stmt_execute($resultUpdate)){
            echo "success";
        }else {
            echo "error";
        }
    }
    }else {
        $queryDelete = "DELETE FROM sport WHERE id = ? ";
        $resultDelete= mysqli_prepare($connection, $queryDelete) or die('error: ' .mysqli_error());
        mysqli_stmt_bind_param($resultDelete, 's',$id);
        if (mysqli_stmt_execute($resultDelete)) {
            echo "success";
        } else {
            echo "error";
        }
    } 
}
elseif ($change == "time") {
    $queryUpdate = 'UPDATE sport SET time = ? WHERE id = ? ;';
    $resultUpdate = mysqli_prepare($connection, $queryUpdate) or die('error: ' .mysqli_error());
    mysqli_stmt_bind_param($resultUpdate, 'ss', $time,$id);
    if (mysqli_stmt_execute($resultUpdate)) {
        echo "success";
    } else {
        echo "error";
    }
}
else {
    echo "error_typeChenge";
}
