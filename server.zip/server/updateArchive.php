<?php

require "connection.php";

$id = $_POST['id'];
$statusArchive = "false";

$queryUpdate = 'UPDATE leaveArchive SET statusArchive = "'.$statusArchive.'" WHERE personalIdemployee = "'.$id.'";';
$result = mysqli_query($connection, $queryUpdate) or die('error: ' .mysql_error());
if ($result != NULL) {
  echo "success";
} else {
  echo "error";
}
