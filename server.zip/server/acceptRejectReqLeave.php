<?php

require "connection.php";

$personalIdemployee = $_POST['personalIdemployee'];
$personalIdmaster = $_POST['personalIdmaster'];
$currentDate = $_POST['currentDate'];
$status = $_POST['status'];
$description = $_POST['description'];
$leaveType = $_POST['leaveType'];
$descriptionLeave = $_POST['descriptionLeave'];

$query = 'SELECT * FROM reqLeave WHERE personalIdemployee = "'.$personalIdemployee.'" AND personalIdmaster = "'.$personalIdmaster.'" AND leavetype = "'.$leaveType.'";';
$result = mysqli_query($connection, $query) or die('error: ' .mysql_error());
$userinfoArr = mysqli_fetch_assoc($result);
$starttime = $userinfoArr['starttime'];
$timeleave = $userinfoArr['timeleave'];
$startdate = $userinfoArr['startdate'];
$fullName = $userinfoArr['fullname'];

if (mysqli_num_rows($result) == 1) {
  $queryInsert = "INSERT INTO leaveArchive VALUES
    (
      NULL ,
      '$fullName',
      '$personalIdemployee',
      '$personalIdmaster',
      '$leaveType',
      '$starttime',
      '$timeleave',
      '$startdate',
      '$description',
      '$descriptionLeave',
      '$currentDate',
      '$status',
      '$status'
    )";
  $resultInsert = mysqli_query($connection, $queryInsert) or die('error: ' .mysql_error());
  $queryUpdate = 'DELETE FROM reqLeave WHERE personalIdemployee = "'.$personalIdemployee.'" AND personalIdmaster = "'.$personalIdmaster.'" AND leavetype = "'.$leaveType.'";';
  $resultUpdate = mysqli_query($connection, $queryUpdate) or die('error: ' .mysql_error());

  if ($resultInsert != NULL َAND $resultUpdate != NULL) {
      echo "success";
  } else {
      echo "error";
  }
}
