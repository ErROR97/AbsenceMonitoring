<?php

require "connection.php";

$personalId = $_POST['personalId'];
$password = $_POST['password'];
$forgetCode = substr(md5($personalId.time()) , 0 , 8);

$query = 'SELECT * FROM employees WHERE personalId = "'.$personalId.'" AND password = "'.$password.'";';
$result = mysqli_query($connection, $query) or die('error: ' .mysql_error());

if($result -> num_rows > 0) {
  $json = json_encode($result -> fetch_assoc(), JSON_UNESCAPED_UNICODE);
  echo "success_$json";
} else {
  echo "error";
}
