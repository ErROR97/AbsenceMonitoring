<?php
error_reporting(E_ERROR | E_PARSE);

//$jsonTimePost = $_POST['post'];
//$personalId = $_POST['personalId'];
//$fullName = $_POST['fullName'];
//$date = $_POST['date'];

$date = "sat";
$personalId = "9537063";
$fullName = "amir";
//achar($code,$personalId,$fullName,$date);
$jsonTimePost = '[{"capacity":{"nameValuePairs":{"sat":12,"mon":"12"}},"code":"1b58c11e","date":{"nameValuePairs":{"day":"sat-mon-tue-wed"}},"id":12,"personalIds":{"nameValuePairs":{"sat":"9537063-9728473-","mon":"9522443-"}},"status":{"nameValuePairs":{"sat":"true","mon":"true"}},"time":"16-18","type":"volleyball"},{"capacity":{"nameValuePairs":{"sun":"12","mon":"12"}},"code":"2fe60d4c","date":{"nameValuePairs":{"day":"sun-mon-"}},"id":7,"personalIds":{"nameValuePairs":{"sun":"","mon":""}},"status":{"nameValuePairs":{"sun":"true","mon":"true"}},"time":"12:12-22:49","type":"volleyball"}]';

$jsonArryDate = json_decode($jsonTimePost,true);
$JsonStatuslArray = array();
for ($counter = 0; $counter < count($jsonArryDate); $counter++) {
  $JsonStatuslArray[$counter] = achar($jsonArryDate[$counter]["code"], $personalId, $fullName, $date);
}
echo json_encode($JsonStatuslArray, JSON_UNESCAPED_UNICODE);
 // for ($i=0; $i < count($JsonStatuslArray); $i++) {
 //   echo $JsonStatuslArray[$i];
 // }


function achar($code , $personalId , $fullName , $date) {
  require "connection.php";
  $JsonStatus = "";
  $JsonStatus->code = $code;
  $query = 'SELECT * FROM sport WHERE code = "'.$code.'" ;';
  $result = mysqli_query($connection, $query) or die('error: ' .mysql_error());
  if (mysqli_num_rows($result) == 1) {
    $SportInfoArr = mysqli_fetch_assoc($result);
    $JSONobjCapacity = json_decode($SportInfoArr['capacity'],true);
    $JSONobjPersonalId = json_decode($SportInfoArr['personalid'],true);
    $JSONobjStatus = json_decode($SportInfoArr['status'],true);
    if ($JSONobjStatus[$date] == "true") {
      $JSONobjPersonalId[$date].= $personalId.">".$fullName."-";
      $JSONobjCapacity[$date]--;
      $ArrypersonalId = explode("-",$JSONobjPersonalId[$date]);
      for ($i = 0; $i < count($ArrypersonalId); $i++) {
        if ($ArrypersonalId[$i] == $personalId.">".$fullName) {
          $JsonStatus->status = "existed";
          return json_encode($JsonStatus);
        }
      }
      if ($JSONobjCapacity[$date] == "0") {
        $JSONobjStatus[$date] = "false";
      }
      $JSONdecodePersonalId = json_encode($JSONobjPersonalId);
      $JSONdecodeCapacity = json_encode($JSONobjCapacity);
      $JSONdecodeStatus = json_encode($JSONobjStatus);
      $queryUpdate = 'UPDATE sport SET personalid = ? , capacity = ? , status = ? WHERE code = ? ;';
      $resultUpdate = mysqli_prepare($connection, $queryUpdate) or die('error: ' .mysqli_error());
      mysqli_stmt_bind_param($resultUpdate, 'ssss', $JSONdecodePersonalId,$JSONdecodeCapacity,$JSONdecodeStatus,$code);
      if (mysqli_stmt_execute($resultUpdate)) {
        $JsonStatus->status = "success";
        return json_encode($JsonStatus);
      } else {
          $JsonStatus->status = "error";
          return json_encode($JsonStatus);
      }
    }
  }
}


function checkConflict($startTime , $endTime , $timeReq1 , $timeReq2){
  if ($timeReq1 <= $endTime AND $timeReq2 >= $startTime) {
    return false;
  }else {
    return true;
  }
}










/*
<?php

require "connection.php";

$code = $_POST['code'];
$personalId = $_POST['personalId'];
$date = $_POST['date'];
// $date = "sat";
// $personalId = "9728473";
// $code = "d23vmn8w";

$query = 'SELECT * FROM sport WHERE code = "'.$code.'" ;';
$result = mysqli_query($connection, $query) or die('error: ' .mysql_error());
if (mysqli_num_rows($result) == 1) {
  $SportInfoArr = mysqli_fetch_assoc($result);
  $JSONobjCapacity = json_decode($SportInfoArr['capacity'],true);
  $JSONobjPersonalId = json_decode($SportInfoArr['personalid'],true);
  $JSONobjStatus = json_decode($SportInfoArr['status'],true);
  if ($JSONobjStatus[$date] == "true") {
    $JSONobjPersonalId[$date].= $personalId."_";
    $JSONobjCapacity[$date]--;
    $ArrypersonalId = explode("_",$JSONobjPersonalId[$date]);
    for ($i = 0; $i < count($ArrypersonalId); $i++) {
      if ($ArrypersonalId[$i] == $personalId) {
        echo "existed";
        return;
      }
    }
    if ($JSONobjCapacity[$date] == "0") {
      $JSONobjStatus[$date] = "false";
    }
    $JSONdecodePersonalId = json_encode($JSONobjPersonalId);
    $JSONdecodeCapacity = json_encode($JSONobjCapacity);
    $JSONdecodeStatus = json_encode($JSONobjStatus);
    //echo "$JSONdecodePersonalId"."\n".$JSONdecodeCapacity."\n".$JSONdecodeStatus;
    $queryUpdate = 'UPDATE sport SET personalid = ? , capacity = ? , status = ? WHERE code = ? ;';
    $resultUpdate = mysqli_prepare($connection, $queryUpdate) or die('error: ' .mysqli_error());
    mysqli_stmt_bind_param($resultUpdate, 'ssss', $JSONdecodePersonalId,$JSONdecodeCapacity,$JSONdecodeStatus,$code);
    if (mysqli_stmt_execute($resultUpdate)) {
      echo "success";
    } else {
        echo "error";
    }
  }
}













// $array = explode("_",$JSONobjPersonalId->$date);
// for ($i = 0 ; $i < count($array) ; $i++) {
//   echo $array[$i];
// }

*/












// $array = explode("_",$JSONobjPersonalId->$date);
// for ($i = 0 ; $i < count($array) ; $i++) {
//   echo $array[$i];
// }
