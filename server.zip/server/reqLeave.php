<?php

require "connection.php";

$personalIdemployee = $_POST['personalId'];
$personalIdmaster = $_POST['personalIdmaster'];
$leavetype = $_POST['leavetype'];
$starttime = $_POST['startTime'];
$timeleave = $_POST['timeLeave'];
$startdate = $_POST['startDate'];
$fullName = $_POST['fullName'];
$descriptionLeave = $_POST['descriptionLeave'];
$currentDate = $_POST['currentdate'];

$query = "INSERT INTO reqLeave VALUES
  (
    NULL ,
    '$fullName',
    '$personalIdemployee',
    '$personalIdmaster',
    '$leavetype',
    '$starttime',
    '$timeleave',
    '$startdate',
    '$currentDate',
    '$descriptionLeave'
  )";
$result = mysqli_query($connection, $query) or die('error: ' .mysql_error());

if ($result != null) {
    echo "success";
} else {
    echo "error";
}
