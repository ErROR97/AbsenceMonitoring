<?php

require "connection.php";
error_reporting(E_ERROR | E_PARSE);

$type = $_POST['type'];
$capacity = $_POST['capacity'];
$time = $_POST['time'];
$date = $_POST['date'];
$code = substr(md5($type.time()) , 0 , 8);

$arryDate = explode("-",$date);
$arryCapacity = explode("-",$capacity);

$dateJson = "";
$capacityJson = "";
$statusJson = "";
$personalIdsJson = "";
for ($i = 0; $i < count($arryDate); $i++) {
  $dateJson->day .= $arryDate[$i]."-";
  $capacityJson->$arryDate[$i] = $arryCapacity[$i];
  $statusJson->$arryDate[$i] = "true";
  $personalIdsJson->$arryDate[$i] = "";
}

$JSONobjDate = json_encode($dateJson);
$JSONobjCapacity = json_encode($capacityJson);
$JSONobjStatus = json_encode($statusJson);
$JSONobjpersonalIds = json_encode($personalIdsJson);

//echo "$JSONobjDate"."\n".$JSONobjCapacity."\n".$JSONobjStatus."\n".$JSONobjpersonalIds;
$queryInsert = "INSERT INTO sport VALUES (NULL, ?, ?, ?, ?, ?, ?, ?)";
$resultInsert= mysqli_prepare($connection, $queryInsert) or die('error: ' .mysqli_error());
mysqli_stmt_bind_param($resultInsert, 'sssssss',$code,$type,$time,$JSONobjDate,$JSONobjpersonalIds,$JSONobjCapacity,$JSONobjStatus);
if (mysqli_stmt_execute($resultInsert)) {
    echo "success";
} else {
    echo "error";
}
