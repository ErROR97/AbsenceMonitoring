<?php
error_reporting(E_ERROR | E_PARSE);

$jsonTimePost = $_POST['post'];
$personalId = $_POST['personalId'];
$fullName = $_POST['fullName'];
$date = $_POST['date'];

//$date = "sun";
//$personalId = "9537063";
//$fullName = "amir";
//achar($code,$personalId,$fullName,$date);
//$jsonTimePost = '[{"capacity":{"nameValuePairs":{"sun":"12","tue":"12","thu":"12"}},"code":"dbe617fd","date":{"nameValuePairs":{"day":"sun-tue-thu-"}},"id":16,"personalIds":{"nameValuePairs":{"sun":"","tue":"","thu":""}},"status":{"nameValuePairs":{"sun":"true","tue":"true","thu":"true"}},"time":"20:00-22:00","type":"volleyball"}]';

$jsonArryDate = json_decode($jsonTimePost,true);
$JsonStatuslArray = array();
for ($counter = 0; $counter < count($jsonArryDate); $counter++) {
  $JsonStatuslArray[$counter] = achar($jsonArryDate[$counter]["code"], $personalId, $fullName, $date);
}
if (count($JsonStatuslArray) >= 1 ){
  $json = json_encode($JsonStatuslArray, JSON_UNESCAPED_UNICODE);
  echo "success_$json";
}else {
  echo "error";
}

function achar($code , $personalId , $fullName , $date) {
  require "connection.php";
  error_reporting(E_ERROR | E_PARSE);
  $JsonStatus = "";
  $JsonStatus->code = $code;
  $query = 'SELECT * FROM sport WHERE code = "'.$code.'" ;';
  $result = mysqli_query($connection, $query) or die('error: ' .mysql_error());
  if (mysqli_num_rows($result) == 1) {
    $SportInfoArr = mysqli_fetch_assoc($result);
    $JSONobjCapacity = json_decode($SportInfoArr['capacity'],true);
    $JSONobjPersonalId = json_decode($SportInfoArr['personalid'],true);
    $JSONobjStatus = json_decode($SportInfoArr['status'],true);

    if ($JSONobjStatus[$date] == "true") {
      $JSONobjPersonalId[$date].= $personalId.">".$fullName."-";
      $JSONobjCapacity[$date]--;
      $ArrypersonalId = explode("-",$JSONobjPersonalId[$date]);
      for ($i = 0; $i < count($ArrypersonalId); $i++) {
        if ($ArrypersonalId[$i] == $personalId.">".$fullName) {
          echo $ArrypersonalId[$i];
          $JsonStatus->status = "existed";
          //return json_encode($JsonStatus);
        }
      }
      if ($JSONobjCapacity[$date] == "0") {
        $JSONobjStatus[$date] = "false";
      }
      $JSONdecodePersonalId = json_encode($JSONobjPersonalId);
      $JSONdecodeCapacity = json_encode($JSONobjCapacity);
      $JSONdecodeStatus = json_encode($JSONobjStatus);
      $queryUpdate = 'UPDATE sport SET personalid = ? , capacity = ? , status = ? WHERE code = ? ;';
      $resultUpdate = mysqli_prepare($connection, $queryUpdate) or die('error: ' .mysqli_error());
      mysqli_stmt_bind_param($resultUpdate, 'ssss', $JSONdecodePersonalId,$JSONdecodeCapacity,$JSONdecodeStatus,$code);
      if (mysqli_stmt_execute($resultUpdate)) {
        $JsonStatus->status = "success";
        return json_encode($JsonStatus);
      } else {
          $JsonStatus->status = "error";
          return json_encode($JsonStatus);
      }
    }
  }
}


function checkConflict($startTime , $endTime , $timeReq1 , $timeReq2){
  if ($timeReq1 <= $endTime AND $timeReq2 >= $startTime) {
    return false;
  }else {
    return true;
  }
}
