<?php

require "connection.php";

$personalIdEmployee = $_POST['personalIdemployee'];

$query = 'SELECT * FROM leaveArchive WHERE personalIdemployee = "'.$personalIdEmployee.'";';
$result = mysqli_query($connection, $query) or die('error: ' .mysql_error());

$Array = array();
if($result -> num_rows > 0) {
    for($i = 0; $i < $result -> num_rows;$i++) {
        $Array[$i] = $result -> fetch_assoc();
    }
    $json = json_encode($Array, JSON_UNESCAPED_UNICODE);
    echo "success_$json";
}
