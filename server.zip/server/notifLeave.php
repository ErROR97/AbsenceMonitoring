<?php

require "connection.php";

$personalIdmaster = $_POST['personalIdmaster'];

$query = 'SELECT * FROM reqLeave WHERE personalIdmaster = "'.$personalIdmaster.'";';
$result = mysqli_query($connection, $query) or die('error: ' .mysql_error());

$notifArray = array();
if($result -> num_rows > 0) {
    for($i = 0; $i < $result -> num_rows;$i++) {
        $notifArray[$i] = $result -> fetch_assoc();
    }
}

echo json_encode($notifArray, JSON_UNESCAPED_UNICODE);
