<?php
error_reporting(E_ERROR | E_PARSE);

$personalId = $_POST['personalId'];
$fullName = $_POST['fullName'];
$date = $_POST['date'];
$currentDate = $_POST['currentDate'];
$address = $_POST['address'];
$flagtime = $_POST['flagtime'];

$queryInsert = "INSERT INTO transport VALUES (NULL, ?, ?, ?, ?, ?, ?)";
$resultInsert = mysqli_prepare($connection, $queryUpdate) or die('error: ' .mysqli_error());
mysqli_stmt_bind_param($resultInsert, 'sdssss', $personalId,$fullName,$flagtime,$date,$address,$currentDate);
if (mysqli_stmt_execute($resultInsert)) {
    echo "success";
} else {
    echo "error";
}
